export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  colors?: string[];
  dimensions?: string;
}

export interface VideoShort {
  id: number;
  thumbnail: string;
  title: string;
  views: string;
  duration: string;
}

export interface YouTubeVideo {
  id: number;
  thumbnail: string;
  title: string;
  videoUrl: string;
  channelName: string;
}

export interface Category {
  id: number;
  name: string;
  image: string;
}

export interface NavItem {
  label: string;
  href: string;
  isNew?: boolean;
}

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  image: string;
  category: string;
}

export interface Testimonial {
  id: number;
  name: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
}