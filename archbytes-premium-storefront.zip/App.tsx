import React, { useState } from 'react';
import { StoreProvider } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Categories } from './components/Categories';
import { PromoGrid } from './components/PromoGrid';
import { ProductSection } from './components/ProductSection';
import { VideoShorts } from './components/VideoShorts';
import { YouTubeSection } from './components/YouTubeSection';
import { BlogSection } from './components/BlogSection';
import { Footer } from './components/Footer';
import { AiAssistant } from './components/AiAssistant';
import { BottomNav } from './components/BottomNav';
import { WhatsAppButton } from './components/WhatsAppButton';
import { Testimonials } from './components/Testimonials';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { SearchOverlay } from './components/SearchOverlay';
import { FEATURED_PRODUCTS } from './constants';

function App() {
  const [isAiModalOpen, setAiModalOpen] = useState(false);

  // Split products for different sections
  const floorPlans = FEATURED_PRODUCTS.filter(p => p.category === 'Floor Plans' || p.category === 'Structural');
  const elevations = FEATURED_PRODUCTS.filter(p => p.category === 'Elevations' || p.category === 'Landscape');
  const interiors = FEATURED_PRODUCTS.filter(p => p.category === 'Interiors');

  return (
    <StoreProvider>
      <div className="min-h-screen bg-white font-sans text-primary pb-16 md:pb-0">
        <Navbar onOpenAi={() => setAiModalOpen(true)} />
        
        <main>
          <Hero />
          <Categories />
          
          {/* Promo Grid - 2 Section Layout for Desktop */}
          <PromoGrid />
          
          {/* Floor Plans Section - Slider on mobile */}
          <ProductSection 
            id="floor-plans"
            title="Trending Floor Plans" 
            subtitle="Architect-approved layouts for your dream home."
            products={floorPlans}
          />

          {/* Video Shorts (Reels) */}
          <VideoShorts />

          {/* Elevations Section */}
          <ProductSection 
            id="elevations"
            title="3D Elevations" 
            subtitle="Stunning exterior designs to make a statement."
            products={elevations}
          />
          
          {/* Interiors Section - Grid */}
          <ProductSection 
            id="interiors"
            title="Interior Concepts" 
            subtitle="Luxury living spaces designed for comfort."
            products={interiors}
            allowFilter={false} // Simple grid without complex filters for this section
          />
          
          {/* Testimonials Section */}
          <Testimonials />

          {/* YouTube Section */}
          <YouTubeSection />

          {/* Banner Strip - Boat Style CTA */}
          <section className="py-16 bg-black relative overflow-hidden">
             <img 
              src="https://images.unsplash.com/photo-1628744876497-eb30460be9f6?auto=format&fit=crop&w=1920&q=80" 
              className="absolute inset-0 w-full h-full object-cover opacity-30" 
              alt="Promotion"
             />
             <div className="relative container mx-auto px-4 text-center text-white">
                <h2 className="text-3xl md:text-5xl font-extrabold mb-4 uppercase tracking-tight">Build with Confidence</h2>
                <p className="text-gray-400 max-w-xl mx-auto mb-8 text-sm md:text-base">
                  Get premium architectural drawings, structural details, and interior layouts delivered to your inbox instantly.
                </p>
                <div className="flex flex-col md:flex-row gap-4 justify-center">
                    <button className="bg-orange-600 text-white px-8 py-3 rounded-full font-bold text-sm uppercase hover:bg-orange-700 transition-colors">
                      Get Consultation
                    </button>
                    <button className="bg-transparent border border-white text-white px-8 py-3 rounded-full font-bold text-sm uppercase hover:bg-white hover:text-black transition-colors">
                      Download Brochure
                    </button>
                </div>
             </div>
          </section>

          {/* Blog Section - Moved to last */}
          <BlogSection />
        </main>

        <Footer />
        <BottomNav />
        <WhatsAppButton />

        {/* Global Modals */}
        <AiAssistant 
          isOpen={isAiModalOpen} 
          onClose={() => setAiModalOpen(false)} 
        />
        <CartDrawer />
        <AuthModal />
        <SearchOverlay />
      </div>
    </StoreProvider>
  );
}

export default App;