import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const getShoppingAdvice = async (query: string): Promise<string> => {
  if (!ai) {
    return "AI styling is currently in demo mode. Please configure your API key to receive real-time advice.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are an expert personal shopper and interior design consultant for a premium lifestyle brand called 'Archbytes'. 
      The user is asking: "${query}".
      
      Provide a short, punchy, and enthusiastic recommendation (max 50 words). 
      Suggest general product categories we might have (like Headphones, Smart Watches, Decor).
      Tone: Sophisticated, helpful, and trendy.`,
    });
    
    return response.text || "I couldn't generate a recommendation right now. Please try browsing our 'New Arrivals'.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting to the styling server. Try again in a moment.";
  }
};