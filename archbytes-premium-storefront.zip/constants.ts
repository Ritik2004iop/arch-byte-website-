import { Product, VideoShort, Category, NavItem, YouTubeVideo, BlogPost, Testimonial } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#hero' },
  { label: 'Floor Plans', href: '#floor-plans' },
  { label: 'Elevations', href: '#elevations' },
  { label: 'Videos', href: '#youtube-videos' },
  { label: 'Blog', href: '#blog' },
  { label: 'Interiors', href: '#interiors', isNew: true },
];

export const CATEGORIES: Category[] = [
  { id: 1, name: '2D Plans', image: 'https://images.unsplash.com/photo-1628745277402-581333d69903?auto=format&fit=crop&w=400&q=80' },
  { id: 2, name: '3D Elevation', image: 'https://images.unsplash.com/photo-1600596542815-e32c0ee32447?auto=format&fit=crop&w=400&q=80' },
  { id: 3, name: 'Interiors', image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4f9d?auto=format&fit=crop&w=400&q=80' },
  { id: 4, name: 'Structural', image: 'https://images.unsplash.com/photo-1531834685032-c34bf0d84c77?auto=format&fit=crop&w=400&q=80' },
  { id: 5, name: 'Landscape', image: 'https://images.unsplash.com/photo-1558905540-212847de5ae6?auto=format&fit=crop&w=400&q=80' },
  { id: 6, name: 'Walkthrough', image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=400&q=80' },
];

export const FEATURED_PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Modern Duplex 40x60',
    category: 'Floor Plans',
    price: 14999,
    originalPrice: 24999,
    rating: 4.9,
    reviews: 120,
    image: 'https://images.unsplash.com/photo-1600596542815-e32c0ee32447?auto=format&fit=crop&w=600&q=80',
    badge: 'Best Seller',
    dimensions: '2400 sq.ft'
  },
  {
    id: 2,
    name: 'Minimalist Villa Front',
    category: 'Elevations',
    price: 8999,
    originalPrice: 15999,
    rating: 4.7,
    reviews: 85,
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=600&q=80',
    badge: 'Trending',
    dimensions: 'G+2'
  },
  {
    id: 3,
    name: 'Luxury Living Room',
    category: 'Interiors',
    price: 5999,
    originalPrice: 9999,
    rating: 4.8,
    reviews: 210,
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=600&q=80',
    badge: 'New',
  },
  {
    id: 4,
    name: 'Farmhouse Layout',
    category: 'Floor Plans',
    price: 12499,
    originalPrice: 18999,
    rating: 4.6,
    reviews: 45,
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=600&q=80',
    dimensions: '1 Acre'
  },
  {
    id: 5,
    name: 'Contemporary Facade',
    category: 'Elevations',
    price: 7999,
    originalPrice: 11999,
    rating: 4.5,
    reviews: 98,
    image: 'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?auto=format&fit=crop&w=600&q=80',
    badge: 'Popular',
    dimensions: 'G+1'
  },
  {
    id: 6,
    name: 'Structural Grid Set',
    category: 'Structural',
    price: 24999,
    originalPrice: 35000,
    rating: 5.0,
    reviews: 12,
    image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=600&q=80',
    badge: 'Professional',
  },
  {
    id: 7,
    name: 'Garden Landscape',
    category: 'Landscape',
    price: 4999,
    originalPrice: 8999,
    rating: 4.3,
    reviews: 67,
    image: 'https://images.unsplash.com/photo-1558905540-212847de5ae6?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 8,
    name: 'Smart Kitchen Layout',
    category: 'Interiors',
    price: 3999,
    rating: 4.8,
    reviews: 340,
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
  },
];

export const VIDEO_SHORTS: VideoShort[] = [
  { id: 1, title: 'Villa Tour 40x60', views: '1.2M', duration: '0:30', thumbnail: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=400&q=80' },
  { id: 2, title: 'Kitchen Makeover', views: '850K', duration: '0:45', thumbnail: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=400&q=80' },
  { id: 3, title: 'Modern Facade', views: '2.1M', duration: '0:20', thumbnail: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=400&q=80' },
  { id: 4, title: 'Small Space Hacks', views: '500K', duration: '0:15', thumbnail: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=400&q=80' },
  { id: 5, title: 'Construction Tips', views: '900K', duration: '1:00', thumbnail: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=400&q=80' },
  { id: 6, title: 'Before & After', views: '1.5M', duration: '0:25', thumbnail: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=400&q=80' },
];

export const YOUTUBE_VIDEOS: YouTubeVideo[] = [
  { id: 1, title: 'Complete House Construction Guide', channelName: 'Archbytes Official', videoUrl: '#', thumbnail: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=800&q=80' },
  { id: 2, title: 'Top 10 Modern House Designs 2024', channelName: 'Archbytes Official', videoUrl: '#', thumbnail: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80' },
  { id: 3, title: 'Interior Design Trends', channelName: 'Archbytes Official', videoUrl: '#', thumbnail: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80' },
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 1,
    title: '5 Tips for Reducing Construction Costs',
    excerpt: 'Learn how to manage your budget effectively without compromising on quality or aesthetics.',
    date: 'Oct 12, 2024',
    category: 'Construction',
    image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 2,
    title: 'The Rise of Sustainable Architecture',
    excerpt: 'Eco-friendly materials and designs are shaping the future of modern homes.',
    date: 'Oct 08, 2024',
    category: 'Trends',
    image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 3,
    title: 'Choosing the Right Floor Plan',
    excerpt: 'Vastu compliance, ventilation, and space utilization explained.',
    date: 'Sep 25, 2024',
    category: 'Planning',
    image: 'https://images.unsplash.com/photo-1534349762913-961d69059250?auto=format&fit=crop&w=600&q=80'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Rajesh Kumar',
    location: 'Bangalore, KA',
    rating: 5,
    comment: 'Archbytes transformed our vision into reality. The 3D elevations were incredibly detailed, and the execution was flawless.',
    date: '2 days ago'
  },
  {
    id: 2,
    name: 'Priya Sharma',
    location: 'Mumbai, MH',
    rating: 5,
    comment: 'Very professional team. I bought the Modern Duplex plan, and the structural drawings saved me so much hassle with the contractors.',
    date: '1 week ago'
  },
  {
    id: 3,
    name: 'Amit Patel',
    location: 'Ahmedabad, GJ',
    rating: 4,
    comment: 'Great designs and affordable pricing. The interior concepts gave my living room a completely new premium look.',
    date: '2 weeks ago'
  },
  {
    id: 4,
    name: 'Sneha Reddy',
    location: 'Hyderabad, TS',
    rating: 5,
    comment: 'Highly recommended! The floor plan was Vastu compliant as promised, and the space utilization is perfect for my small plot.',
    date: '3 weeks ago'
  },
  {
    id: 5,
    name: 'Vikram Singh',
    location: 'Delhi, NCR',
    rating: 5,
    comment: 'The walkthrough video helped me visualize my future home before laying a single brick. Exceptional quality work.',
    date: '1 month ago'
  },
  {
    id: 6,
    name: 'Anjali Menon',
    location: 'Kochi, KL',
    rating: 4,
    comment: 'Good customer support. They helped me customize the standard plan to fit my specific requirements quickly.',
    date: '1 month ago'
  },
  {
    id: 7,
    name: 'David Fernandes',
    location: 'Goa',
    rating: 5,
    comment: 'I was skeptical about buying architectural plans online, but Archbytes exceeded my expectations. Fantastic detailing.',
    date: '2 months ago'
  },
  {
    id: 8,
    name: 'Meera Iyer',
    location: 'Chennai, TN',
    rating: 5,
    comment: 'The landscape designs are beautiful. My garden looks like a resort now. Thank you for the amazing suggestions.',
    date: '2 months ago'
  },
  {
    id: 9,
    name: 'Rohit Verma',
    location: 'Pune, MH',
    rating: 4,
    comment: 'Simple process, great value for money. The downloadable files were high resolution and easy for my engineer to read.',
    date: '3 months ago'
  },
  {
    id: 10,
    name: 'Kavita Das',
    location: 'Kolkata, WB',
    rating: 5,
    comment: 'A one-stop solution for home design. From structural to interiors, everything fits together perfectly in their packages.',
    date: '3 months ago'
  }
];