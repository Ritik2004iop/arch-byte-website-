import React from 'react';
import { Play } from 'lucide-react';
import { VIDEO_SHORTS } from '../constants';

export const VideoShorts: React.FC = () => {
  return (
    <section className="py-8 md:py-16 bg-gray-50 text-gray-900 overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-3 md:mb-4">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold flex items-center gap-2">
              <span className="bg-orange-600 text-white text-xs px-2 py-0.5 rounded uppercase tracking-wider">Live</span>
              Arch<span className="text-gray-400">Reels</span>
            </h2>
            <p className="text-gray-500 mt-1 text-sm md:text-base">See our products in action.</p>
          </div>
          <button className="hidden md:block text-sm font-bold border-b border-gray-300 hover:text-orange-600 hover:border-orange-600 transition-colors">
            View All Shorts
          </button>
        </div>

        <div className="relative">
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 snap-x snap-mandatory">
            {VIDEO_SHORTS.map((video) => (
                <div 
                    key={video.id} 
                    className="flex-shrink-0 w-[180px] md:w-[260px] h-[320px] md:h-[450px] relative rounded-xl overflow-hidden cursor-pointer group snap-center border border-gray-200 shadow-sm hover:shadow-xl transition-shadow"
                >
                    <img 
                        src={video.thumbnail} 
                        alt={video.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/80" />
                    
                    {/* Play Icon Overlay */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/50">
                            <Play className="w-5 h-5 text-white fill-white" />
                        </div>
                    </div>

                    <div className="absolute bottom-0 left-0 p-3 md:p-4 w-full text-white">
                        <h3 className="font-bold text-sm md:text-lg leading-tight mb-1 line-clamp-2">{video.title}</h3>
                        <div className="flex items-center justify-between text-[10px] md:text-xs text-gray-300">
                            <span>{video.views} views</span>
                            <span>{video.duration}</span>
                        </div>
                    </div>
                </div>
            ))}
            </div>
        </div>
      </div>
    </section>
  );
};