import React from 'react';
import { X, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const CartDrawer: React.FC = () => {
  const { isCartOpen, setIsCartOpen, cart, removeFromCart, updateQuantity, cartTotal } = useStore();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={() => setIsCartOpen(false)}
      />

      {/* Drawer */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl animate-slide-up md:animate-fade-in flex flex-col">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-white z-10">
          <h2 className="text-xl font-extrabold flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-orange-600" />
            Your Cart <span className="text-gray-400 text-sm font-normal">({cart.length} items)</span>
          </h2>
          <button onClick={() => setIsCartOpen(false)} className="hover:bg-gray-100 p-2 rounded-full transition-colors">
            <X className="w-6 h-6 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
               <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center">
                  <ShoppingBag className="w-10 h-10 text-gray-300" />
               </div>
               <div>
                  <h3 className="font-bold text-gray-900">Your cart is empty</h3>
                  <p className="text-gray-500 text-sm mt-1">Looks like you haven't made your choice yet.</p>
               </div>
               <button 
                  onClick={() => setIsCartOpen(false)}
                  className="mt-4 bg-orange-600 text-white px-6 py-3 rounded-full font-bold text-sm hover:bg-orange-700"
               >
                  Start Browsing
               </button>
            </div>
          ) : (
            <div className="space-y-6">
              {cart.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-bold text-sm text-gray-900 line-clamp-2">{item.name}</h4>
                      <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 mb-3">{item.category}</p>
                    <div className="flex items-center justify-between">
                       <span className="font-bold text-orange-600">₹{item.price.toLocaleString()}</span>
                       <div className="flex items-center border border-gray-200 rounded-md">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="p-1 hover:bg-gray-100 text-gray-600"
                          >
                             <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-bold min-w-[20px] text-center">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="p-1 hover:bg-gray-100 text-gray-600"
                          >
                             <Plus className="w-3 h-3" />
                          </button>
                       </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="p-5 border-t border-gray-100 bg-gray-50">
             <div className="flex justify-between items-center mb-4">
                <span className="text-gray-600 font-medium">Subtotal</span>
                <span className="text-xl font-extrabold text-gray-900">₹{cartTotal.toLocaleString()}</span>
             </div>
             <p className="text-xs text-gray-500 mb-4 text-center">Taxes and shipping calculated at checkout</p>
             <button className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-wider hover:bg-gray-900 transition-colors shadow-lg">
                Checkout Now
             </button>
          </div>
        )}
      </div>
    </div>
  );
};