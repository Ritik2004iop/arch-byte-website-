import React from 'react';
import { Home, LayoutGrid, Gift, UserPen, MessageCircle } from 'lucide-react';

export const BottomNav: React.FC = () => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 px-4 py-2 pb-safe">
      <div className="flex justify-between items-center">
        <a href="#hero" className="flex flex-col items-center gap-1 min-w-[60px]">
          <Home className="w-5 h-5 text-black" />
          <span className="text-[10px] font-bold text-black border-b-2 border-orange-600 pb-0.5">Home</span>
        </a>
        <button className="flex flex-col items-center gap-1 min-w-[60px] text-gray-500 hover:text-black">
          <LayoutGrid className="w-5 h-5" />
          <span className="text-[10px] font-medium">Categories</span>
        </button>
        <button className="flex flex-col items-center gap-1 min-w-[60px] text-gray-500 hover:text-black">
          <Gift className="w-5 h-5" />
          <span className="text-[10px] font-medium">Rewards</span>
        </button>
        <button className="flex flex-col items-center gap-1 min-w-[60px] text-gray-500 hover:text-black">
          <UserPen className="w-5 h-5" />
          <span className="text-[10px] font-medium">Personalisation</span>
        </button>
        <button className="flex flex-col items-center gap-1 min-w-[60px] text-gray-500 hover:text-black">
          <MessageCircle className="w-5 h-5" />
          <span className="text-[10px] font-medium">Chat</span>
        </button>
      </div>
    </div>
  );
};