import React from 'react';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin, ChevronRight } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#111] text-white pt-16 pb-8 border-t border-gray-900">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <a href="/" className="text-3xl font-extrabold tracking-tighter uppercase font-sans flex items-center gap-1">
              <span>Arch</span><span className="text-orange-600">bytes</span>
            </a>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              Providing premium architectural drawings, 3D elevations, and structural solutions online. We turn your dream home concepts into buildable reality.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center hover:bg-orange-600 transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center hover:bg-orange-600 transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center hover:bg-orange-600 transition-all">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center hover:bg-orange-600 transition-all">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-6 relative inline-block">
              Quick Links
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-orange-600 rounded-full"></span>
            </h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li><a href="#hero" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Home</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> About Us</a></li>
              <li><a href="#floor-plans" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Portfolio</a></li>
              <li><a href="#blog" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Blog</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Contact Us</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-6 relative inline-block">
              Our Services
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-orange-600 rounded-full"></span>
            </h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> 2D Floor Plans</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> 3D Elevations</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Structural Design</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Interior Layouts</a></li>
              <li><a href="#" className="hover:text-orange-500 transition-colors flex items-center gap-2"><ChevronRight className="w-3 h-3 text-orange-600" /> Estimation</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-lg mb-6 relative inline-block">
              Contact Us
              <span className="absolute -bottom-2 left-0 w-8 h-1 bg-orange-600 rounded-full"></span>
            </h4>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>123, Tech Park, Wakad,<br />Pune, Maharashtra - 411057</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-orange-600 flex-shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-orange-600 flex-shrink-0" />
                <span>hello@archbytes.com</span>
              </li>
            </ul>
            
            <div className="mt-6">
                 <h5 className="font-bold text-sm mb-2 text-white">Subscribe to our Newsletter</h5>
                 <div className="flex">
                    <input 
                        type="email" 
                        placeholder="Email Address" 
                        className="bg-gray-800 text-white text-xs px-3 py-2 rounded-l w-full focus:outline-none focus:ring-1 focus:ring-orange-600"
                    />
                    <button className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-2 rounded-r transition-colors">
                        <ChevronRight className="w-4 h-4" />
                    </button>
                 </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} Archbytes Technologies. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-orange-500 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Refund Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};