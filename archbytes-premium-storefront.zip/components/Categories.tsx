import React from 'react';
import { CATEGORIES } from '../constants';

export const Categories: React.FC = () => {
  return (
    <section className="py-8 bg-white border-b border-gray-100">
      <div className="container mx-auto px-4">
        <h3 className="text-lg font-bold mb-4 px-2 md:hidden">Categories</h3>
        <div className="flex gap-4 md:gap-10 overflow-x-auto no-scrollbar pb-2 snap-x px-2">
          {CATEGORIES.map((cat) => (
            <div key={cat.id} className="flex-shrink-0 snap-start group cursor-pointer flex flex-col items-center gap-2 min-w-[80px]">
              <div className="w-20 h-20 md:w-28 md:h-28 rounded-full p-1 border-2 border-transparent group-hover:border-orange-600 transition-all">
                <div className="w-full h-full rounded-full overflow-hidden bg-gray-100">
                    <img 
                        src={cat.image} 
                        alt={cat.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    />
                </div>
              </div>
              <span className="text-xs md:text-sm font-bold text-center text-gray-800 group-hover:text-orange-600 transition-colors">
                {cat.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};