import React from 'react';
import { Star, Quote, MapPin } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-16 bg-white border-t border-gray-100">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-extrabold uppercase tracking-tight text-black mb-3">
            Trusted by <span className="text-orange-600">Homeowners</span>
          </h2>
          <p className="text-gray-500 text-sm md:text-base max-w-2xl mx-auto">
            See what our clients across the country have to say about their journey with Archbytes.
          </p>
        </div>

        <div className="flex overflow-x-auto gap-6 pb-8 snap-x snap-mandatory no-scrollbar">
          {TESTIMONIALS.map((review) => (
            <div 
              key={review.id} 
              className="flex-shrink-0 w-[300px] md:w-[350px] bg-gray-50 p-6 rounded-2xl border border-gray-100 snap-center relative group hover:shadow-lg transition-shadow duration-300"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-orange-100 fill-orange-100 group-hover:text-orange-200 group-hover:fill-orange-200 transition-colors" />
              
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < review.rating ? 'text-orange-500 fill-orange-500' : 'text-gray-300'}`} 
                  />
                ))}
              </div>

              <p className="text-gray-700 text-sm leading-relaxed mb-6 min-h-[80px]">
                "{review.comment}"
              </p>

              <div className="flex items-center gap-3 mt-auto">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center font-bold text-gray-600">
                   {review.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-gray-900">{review.name}</h4>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <MapPin className="w-3 h-3" />
                    {review.location}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};