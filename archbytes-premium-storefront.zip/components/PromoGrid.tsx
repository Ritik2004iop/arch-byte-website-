import React from 'react';
import { ArrowRight } from 'lucide-react';

export const PromoGrid: React.FC = () => {
  return (
    <section className="py-6 md:py-12 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
          {/* Banner 1: Residential/Ready Plans */}
          <div className="relative h-[250px] md:h-[400px] rounded-2xl overflow-hidden group cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500">
            <img 
               src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80" 
               alt="Residential Plans"
               className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            
            <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-10 text-white">
               <span className="bg-orange-600 text-white text-[10px] font-bold px-2 py-1 rounded w-max mb-3 uppercase tracking-wider">
                  Ready to Build
               </span>
               <h3 className="text-2xl md:text-4xl font-extrabold mb-2 uppercase tracking-tight leading-none">
                  Residential Plans
               </h3>
               <p className="text-gray-200 mb-6 font-medium text-sm md:text-base max-w-sm">
                  Explore 1000+ Vastu compliant floor plans designed for modern Indian families.
               </p>
               <button className="bg-white text-black px-6 py-3 rounded-full font-bold text-xs md:text-sm w-max flex items-center gap-2 hover:bg-orange-600 hover:text-white transition-all transform group-hover:translate-x-2">
                 View Collections <ArrowRight className="w-4 h-4" />
               </button>
            </div>
          </div>

          {/* Banner 2: Interiors/Consultation */}
          <div className="relative h-[250px] md:h-[400px] rounded-2xl overflow-hidden group cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500">
            <img 
               src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80" 
               alt="Premium Interiors"
               className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            
            <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-10 text-white">
               <span className="bg-white text-black text-[10px] font-bold px-2 py-1 rounded w-max mb-3 uppercase tracking-wider">
                  Premium Service
               </span>
               <h3 className="text-2xl md:text-4xl font-extrabold mb-2 uppercase tracking-tight leading-none">
                  Interior Design
               </h3>
               <p className="text-gray-200 mb-6 font-medium text-sm md:text-base max-w-sm">
                  Get personalized interior layouts and 3D visualization from expert architects.
               </p>
               <button className="backdrop-blur-md bg-white/20 border border-white/50 text-white px-6 py-3 rounded-full font-bold text-xs md:text-sm w-max flex items-center gap-2 hover:bg-white hover:text-black transition-all transform group-hover:translate-x-2">
                 Book Consultation <ArrowRight className="w-4 h-4" />
               </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};