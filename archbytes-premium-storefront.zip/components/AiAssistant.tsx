import React, { useState } from 'react';
import { X, Sparkles, Send, Loader2 } from 'lucide-react';
import { getShoppingAdvice } from '../services/geminiService';

interface AiAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiAssistant: React.FC<AiAssistantProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setResponse(null);
    
    // Simulate slight delay for UX if API is instant, makes it feel like "thinking"
    const advice = await getShoppingAdvice(query);
    
    setResponse(advice);
    setIsLoading(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-slide-up flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-300" />
              AI Stylist
            </h3>
            <p className="text-indigo-100 text-sm mt-1">
              Ask me for outfit ideas, home decor tips, or gift advice.
            </p>
          </div>
          <button 
            onClick={onClose}
            className="text-white/80 hover:text-white hover:bg-white/20 rounded-full p-1 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 flex-1 overflow-y-auto min-h-[200px]">
          {response ? (
            <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 animate-fade-in">
              <h4 className="font-bold text-indigo-900 mb-2 text-sm uppercase tracking-wide">Suggestion</h4>
              <p className="text-gray-800 leading-relaxed">{response}</p>
              <button 
                onClick={() => setResponse(null)}
                className="mt-4 text-xs font-bold text-indigo-600 hover:underline"
              >
                Ask something else
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 space-y-4">
              {!isLoading && (
                <>
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-2">
                    <Sparkles className="w-8 h-8 text-gray-300" />
                  </div>
                  <p className="text-sm">
                    "I need a minimalist desk setup under ₹5000"
                    <br />
                    "Best headphones for gym"
                  </p>
                </>
              )}
              {isLoading && (
                 <div className="flex flex-col items-center">
                   <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-2" />
                   <span className="text-sm font-medium text-indigo-600">Thinking...</span>
                 </div>
              )}
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-100 bg-gray-50">
          <form onSubmit={handleAsk} className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your question..."
              className="w-full pl-4 pr-12 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
              disabled={isLoading}
            />
            <button 
              type="submit"
              disabled={!query.trim() || isLoading}
              className="absolute right-2 top-2 bottom-2 w-9 bg-black text-white rounded-lg flex items-center justify-center hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};