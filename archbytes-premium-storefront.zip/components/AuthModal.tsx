import React, { useState } from 'react';
import { X, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const AuthModal: React.FC = () => {
  const { isAuthOpen, setIsAuthOpen, login } = useStore();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (!isAuthOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login
    login(name || email.split('@')[0], email);
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={() => setIsAuthOpen(false)}
      />
      
      <div className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden animate-slide-up">
        <button 
          onClick={() => setIsAuthOpen(false)}
          className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors z-10"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>

        <div className="p-8">
           <div className="text-center mb-8">
              <h2 className="text-2xl font-extrabold mb-2 uppercase tracking-tight">
                {isLogin ? 'Welcome Back' : 'Join Archbytes'}
              </h2>
              <p className="text-gray-500 text-sm">
                {isLogin ? 'Access your saved plans and orders.' : 'Start building your dream home today.'}
              </p>
           </div>

           <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div className="space-y-1">
                   <label className="text-xs font-bold text-gray-700 ml-1">Full Name</label>
                   <div className="relative">
                      <User className="absolute left-4 top-3.5 w-4 h-4 text-gray-400" />
                      <input 
                        type="text" 
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-600 transition-all font-medium"
                        placeholder="John Doe"
                      />
                   </div>
                </div>
              )}

              <div className="space-y-1">
                   <label className="text-xs font-bold text-gray-700 ml-1">Email Address</label>
                   <div className="relative">
                      <Mail className="absolute left-4 top-3.5 w-4 h-4 text-gray-400" />
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-600 transition-all font-medium"
                        placeholder="name@example.com"
                      />
                   </div>
              </div>

              <div className="space-y-1">
                   <label className="text-xs font-bold text-gray-700 ml-1">Password</label>
                   <div className="relative">
                      <Lock className="absolute left-4 top-3.5 w-4 h-4 text-gray-400" />
                      <input 
                        type="password" 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-600 transition-all font-medium"
                        placeholder="••••••••"
                      />
                   </div>
              </div>

              {isLogin && (
                <div className="flex justify-end">
                   <a href="#" className="text-xs font-bold text-orange-600 hover:underline">Forgot Password?</a>
                </div>
              )}

              <button 
                type="submit"
                className="w-full bg-black text-white py-3.5 rounded-xl font-bold uppercase tracking-wide hover:bg-gray-800 transition-colors flex items-center justify-center gap-2 mt-2"
              >
                {isLogin ? 'Login' : 'Create Account'} <ArrowRight className="w-4 h-4" />
              </button>
           </form>

           <div className="mt-6 text-center">
              <p className="text-xs text-gray-500 font-medium">
                 {isLogin ? "Don't have an account? " : "Already have an account? "}
                 <button 
                    onClick={() => setIsLogin(!isLogin)}
                    className="text-orange-600 font-bold hover:underline"
                 >
                    {isLogin ? 'Sign Up' : 'Login'}
                 </button>
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};