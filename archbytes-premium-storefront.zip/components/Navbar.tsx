import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, User, Menu, X, Sparkles, LogOut } from 'lucide-react';
import { NAV_ITEMS } from '../constants';
import { useStore } from '../context/StoreContext';

interface NavbarProps {
  onOpenAi: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAi }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Store Context
  const { 
    cart, 
    setIsCartOpen, 
    user, 
    setIsAuthOpen, 
    logout,
    setIsSearchOpen 
  } = useStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <>
      {/* Promotion Bar */}
      <div className="bg-black text-white text-[10px] md:text-xs font-bold py-2 text-center tracking-widest uppercase">
        Get 50% OFF on 3D Elevations | Limited Time Offer
      </div>

      <nav
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-3' : 'bg-white py-4'
        }`}
      >
        <div className="container mx-auto px-4 md:px-8 flex items-center justify-between">
          {/* Logo & Mobile Menu */}
          <div className="flex items-center gap-3">
            <button 
              className="md:hidden p-1"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="w-6 h-6" />
            </button>
            <a href="/" className="text-xl md:text-2xl font-extrabold tracking-tighter uppercase font-sans flex items-center gap-1">
              <span>Arch</span><span className="text-orange-600">bytes</span>
            </a>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => { e.preventDefault(); handleNavClick(item.href); }}
                className="text-sm font-bold text-gray-700 hover:text-orange-600 transition-colors relative group uppercase tracking-tight"
              >
                {item.label}
                {item.isNew && (
                  <span className="absolute -top-3 -right-3 text-[9px] bg-orange-600 text-white px-1.5 py-0.5 rounded-full animate-bounce">
                    NEW
                  </span>
                )}
              </a>
            ))}
          </div>

          {/* Icons */}
          <div className="flex items-center gap-3 md:gap-5">
            <button 
              onClick={onOpenAi}
              className="hidden md:flex items-center gap-1.5 text-xs font-bold bg-black text-white px-3 py-1.5 rounded-full hover:bg-orange-600 transition-colors shadow-sm"
            >
              <Sparkles className="w-3 h-3 text-yellow-400" />
              AI Architect
            </button>

            <button 
                onClick={() => setIsSearchOpen(true)}
                className="hover:text-orange-600 transition-colors"
            >
              <Search className="w-5 h-5 md:w-6 md:h-6" />
            </button>

            {/* User Icon / Profile */}
            {user ? (
               <div className="relative group">
                  <button className="hover:text-orange-600 transition-colors flex items-center gap-1">
                     <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center text-xs font-bold border border-orange-200">
                        {user.name.charAt(0).toUpperCase()}
                     </div>
                  </button>
                  {/* Dropdown */}
                  <div className="absolute right-0 top-full pt-2 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity">
                      <div className="bg-white border border-gray-100 shadow-xl rounded-xl p-3 min-w-[150px] flex flex-col gap-2">
                          <div className="px-2 py-1 text-xs font-bold border-b border-gray-50 text-gray-400">
                             Hello, {user.name}
                          </div>
                          <button onClick={logout} className="flex items-center gap-2 text-xs font-bold text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                              <LogOut className="w-3 h-3" /> Logout
                          </button>
                      </div>
                  </div>
               </div>
            ) : (
                <button 
                    onClick={() => setIsAuthOpen(true)}
                    className="hover:text-orange-600 transition-colors"
                >
                    <User className="w-5 h-5 md:w-6 md:h-6" />
                </button>
            )}

            <button 
                onClick={() => setIsCartOpen(true)}
                className="relative hover:text-orange-600 transition-colors"
            >
              <ShoppingBag className="w-5 h-5 md:w-6 md:h-6" />
              {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-[9px] w-3.5 h-3.5 flex items-center justify-center rounded-full font-bold animate-fade-in">
                    {cartCount}
                  </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="w-[85%] bg-white h-full shadow-2xl flex flex-col animate-slide-up">
            <div className="flex justify-between items-center p-5 border-b border-gray-100 bg-gray-50">
                <span className="text-lg font-extrabold uppercase tracking-tighter">Arch<span className="text-orange-600">bytes</span></span>
              <button onClick={() => setIsMobileMenuOpen(false)}>
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto py-4">
               <div className="px-5 mb-6">
                 <p className="text-xs font-bold text-gray-400 uppercase mb-3">Categories</p>
                 <div className="flex flex-col gap-4">
                    {NAV_ITEMS.map((item) => (
                        <a 
                        key={item.label} 
                        href={item.href} 
                        className="text-base font-bold text-gray-800 flex justify-between items-center"
                        onClick={(e) => { e.preventDefault(); handleNavClick(item.href); }}
                        >
                        {item.label}
                        {item.isNew && <span className="text-[10px] bg-orange-600 text-white px-2 py-0.5 rounded-sm">NEW</span>}
                        </a>
                    ))}
                 </div>
               </div>
               
               <div className="px-5 pt-4 border-t border-gray-100">
                    <button 
                        onClick={() => { onOpenAi(); setIsMobileMenuOpen(false); }}
                        className="w-full bg-gradient-to-r from-gray-900 to-black text-white py-3 rounded-lg font-bold flex items-center justify-center gap-2 shadow-lg"
                    >
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                        Ask AI Architect
                    </button>
               </div>
            </div>
          </div>
          <div 
            className="flex-1 bg-black/40 backdrop-blur-sm"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        </div>
      )}
    </>
  );
};