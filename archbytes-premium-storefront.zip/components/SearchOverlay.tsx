import React, { useEffect, useRef } from 'react';
import { Search, X, ArrowRight, Star } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { FEATURED_PRODUCTS } from '../constants';

export const SearchOverlay: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery, addToCart } = useStore();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const filteredProducts = searchQuery 
    ? FEATURED_PRODUCTS.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="fixed inset-0 z-[100] bg-white flex flex-col animate-fade-in">
      {/* Header */}
      <div className="border-b border-gray-100 p-4 flex items-center gap-4">
        <Search className="w-5 h-5 text-gray-400" />
        <input
          ref={inputRef}
          type="text"
          placeholder="Search for plans, elevations, or interiors..."
          className="flex-1 text-lg font-medium outline-none placeholder:text-gray-300"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button 
          onClick={() => setIsSearchOpen(false)}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="w-6 h-6 text-gray-500" />
        </button>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-50">
        <div className="container mx-auto max-w-4xl">
          {searchQuery && (
             <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-6">
                {filteredProducts.length} Results Found
             </h3>
          )}

          {!searchQuery && (
             <div className="text-center mt-20 text-gray-400">
                <Search className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>Start typing to find your dream design.</p>
             </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredProducts.map(product => (
              <div key={product.id} className="bg-white p-3 rounded-xl border border-gray-100 flex gap-4 hover:shadow-md transition-shadow">
                <div className="w-24 h-24 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 flex flex-col justify-center">
                  <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-gray-900">{product.name}</h4>
                        <p className="text-xs text-gray-500">{product.category}</p>
                      </div>
                      <div className="flex items-center gap-1 bg-gray-100 px-1.5 py-0.5 rounded text-[10px] font-bold">
                          <Star className="w-3 h-3 text-orange-500 fill-orange-500" />
                          {product.rating}
                      </div>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                     <span className="font-bold text-orange-600">₹{product.price.toLocaleString()}</span>
                     <button 
                        onClick={() => {
                            addToCart(product);
                            setIsSearchOpen(false);
                        }}
                        className="text-xs font-bold bg-black text-white px-3 py-1.5 rounded hover:bg-orange-600 transition-colors"
                     >
                        Add
                     </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};