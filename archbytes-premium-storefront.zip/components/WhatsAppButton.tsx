import React from 'react';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  return (
    <a 
      href="https://wa.me/" 
      target="_blank" 
      rel="noopener noreferrer"
      className="fixed bottom-20 md:bottom-10 right-4 md:right-8 z-40 flex items-center gap-2 group"
    >
      <div className="bg-white text-gray-800 px-4 py-2 rounded-full shadow-lg text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-300 hidden md:block border border-gray-100">
        Chat with Architect
      </div>
      <div className="w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform duration-300 hover:shadow-[#25d366]/40">
        <MessageCircle className="w-8 h-8 text-white fill-white" />
      </div>
    </a>
  );
};