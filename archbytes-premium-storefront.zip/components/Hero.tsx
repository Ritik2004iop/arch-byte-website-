import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

const SLIDES = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=80',
    title: 'Modern Villas',
    subtitle: 'Starting @ ₹9,999',
    button: 'Explore Plans'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1920&q=80',
    title: 'Luxury Elevations',
    subtitle: 'Transform your facade',
    button: 'View Designs'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4f9d?auto=format&fit=crop&w=1920&q=80',
    title: 'Interior Concepts',
    subtitle: 'Premium Living Spaces',
    button: 'Shop Now'
  }
];

export const Hero: React.FC = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrent((prev) => (prev + 1) % SLIDES.length);
  const prevSlide = () => setCurrent((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);

  return (
    <section id="hero" className="relative w-full h-[500px] md:h-[600px] overflow-hidden bg-gray-900 group">
      {SLIDES.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === current ? 'opacity-100 z-10' : 'opacity-0 z-0'
          }`}
        >
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent md:bg-gradient-to-r md:from-black/80 md:via-transparent" />
          
          <div className="absolute bottom-12 left-4 md:bottom-auto md:top-1/2 md:-translate-y-1/2 md:left-20 text-white max-w-lg">
             <span className="inline-block px-3 py-1 bg-orange-600 text-white text-[10px] md:text-xs font-bold uppercase tracking-wider mb-4 rounded-sm">
                Best Seller
             </span>
             <h2 className="text-4xl md:text-6xl font-extrabold mb-2 leading-tight tracking-tight">
               {slide.title}
             </h2>
             <p className="text-lg md:text-2xl font-light text-gray-200 mb-6">
               {slide.subtitle}
             </p>
             <button className="bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-gray-200 transition-colors flex items-center gap-2">
               {slide.button} <ArrowRight className="w-4 h-4" />
             </button>
          </div>
        </div>
      ))}

      {/* Navigation Arrows */}
      <button 
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/10 backdrop-blur-md p-2 rounded-full hover:bg-white/20 text-white opacity-0 group-hover:opacity-100 transition-opacity hidden md:block"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button 
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/10 backdrop-blur-md p-2 rounded-full hover:bg-white/20 text-white opacity-0 group-hover:opacity-100 transition-opacity hidden md:block"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`w-2 h-2 rounded-full transition-all ${
              idx === current ? 'w-6 bg-orange-600' : 'bg-white/50 hover:bg-white'
            }`}
          />
        ))}
      </div>
    </section>
  );
};