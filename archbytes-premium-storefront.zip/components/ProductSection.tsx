import React, { useState, useMemo } from 'react';
import { Star, Heart, Eye, ShoppingCart, Filter, ChevronDown, X, ArrowRight, Check } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductSectionProps {
  id?: string;
  title: string;
  subtitle?: string;
  products: Product[];
  allowFilter?: boolean;
}

export const ProductSection: React.FC<ProductSectionProps> = ({ id, title, subtitle, products, allowFilter = true }) => {
  const { addToCart } = useStore();
  const [activeCategory, setActiveCategory] = useState('All');
  const [priceRange, setPriceRange] = useState<'all' | 'under-5000' | '5000-15000' | 'above-15000'>('all');
  const [minRating, setMinRating] = useState<number>(0);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Extract unique categories
  const categories = useMemo(() => {
    const cats = new Set(products.map((p) => p.category));
    return ['All', ...Array.from(cats)];
  }, [products]);

  // Filter Logic
  const filteredProducts = products.filter((product) => {
    if (!allowFilter) return true;
    // Category Filter
    if (activeCategory !== 'All' && product.category !== activeCategory) return false;

    // Price Filter
    if (priceRange === 'under-5000' && product.price >= 5000) return false;
    if (priceRange === '5000-15000' && (product.price < 5000 || product.price > 15000)) return false;
    if (priceRange === 'above-15000' && product.price <= 15000) return false;

    // Rating Filter
    if (minRating > 0 && product.rating < minRating) return false;

    return true;
  });

  const clearFilters = () => {
    setActiveCategory('All');
    setPriceRange('all');
    setMinRating(0);
  };

  const hasActiveFilters = activeCategory !== 'All' || priceRange !== 'all' || minRating > 0;

  return (
    <section id={id} className="py-12 bg-white border-b border-gray-100">
      <div className="container mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold text-black uppercase tracking-tight">
                {title} <span className="text-orange-600">.</span>
            </h2>
            {subtitle && <p className="text-gray-500 text-sm mt-1">{subtitle}</p>}
          </div>
          <button className="hidden md:flex items-center gap-1 text-sm font-bold text-orange-600 hover:text-black transition-colors">
            View All <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Bar - Only show if allowFilter is true */}
        {allowFilter && (
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 md:gap-3 items-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs md:text-sm font-bold transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-black text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat}
              </button>
            ))}
            <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="ml-auto flex items-center gap-1 text-xs font-bold text-gray-500 hover:text-black"
            >
                <Filter className="w-3 h-3" /> Filters
            </button>
          </div>

          {/* Collapsible Filter Panel */}
          {isFilterOpen && (
             <div className="mt-4 p-4 bg-gray-50 rounded-xl animate-fade-in border border-gray-100">
                <div className="flex justify-between items-start mb-2">
                    <h4 className="text-xs font-bold uppercase text-gray-400">Refine Selection</h4>
                    <button onClick={() => setIsFilterOpen(false)}><X className="w-4 h-4 text-gray-400" /></button>
                </div>
                <div className="flex flex-wrap gap-4">
                     <select 
                        className="bg-white border border-gray-200 text-xs font-bold p-2 rounded-lg"
                        value={priceRange}
                        onChange={(e) => setPriceRange(e.target.value as any)}
                     >
                        <option value="all">Price: All</option>
                        <option value="under-5000">Under ₹5,000</option>
                        <option value="5000-15000">₹5,000 - ₹15,000</option>
                        <option value="above-15000">Above ₹15,000</option>
                     </select>
                     <select 
                        className="bg-white border border-gray-200 text-xs font-bold p-2 rounded-lg"
                        value={minRating}
                        onChange={(e) => setMinRating(Number(e.target.value))}
                     >
                        <option value="0">Rating: All</option>
                        <option value="4">4 Stars & up</option>
                        <option value="4.5">4.5 Stars & up</option>
                     </select>
                     {hasActiveFilters && (
                        <button onClick={clearFilters} className="text-xs text-orange-500 font-bold hover:underline">Clear</button>
                     )}
                </div>
             </div>
          )}
        </div>
        )}

        {/* Product Grid / Slider */}
        {filteredProducts.length > 0 ? (
            // Flex container with overflow for mobile sliding, Grid for desktop
          <div className="flex overflow-x-auto snap-x gap-4 md:grid md:grid-cols-4 md:gap-8 pb-4 -mx-4 px-4 md:mx-0 md:px-0 no-scrollbar touch-pan-x">
            {filteredProducts.map((product) => (
              <div key={product.id} className="flex-shrink-0 min-w-[280px] md:min-w-0 snap-center group bg-white rounded-xl relative hover:shadow-lg transition-all duration-300 border border-gray-100">
                
                {/* Badge */}
                {product.badge && (
                  <span className="absolute top-2 left-2 bg-yellow-400 text-black text-[9px] font-bold px-2 py-0.5 uppercase tracking-wide z-10 rounded-sm">
                    {product.badge}
                  </span>
                )}

                {/* Wishlist */}
                <button className="absolute top-2 right-2 z-10 w-7 h-7 flex items-center justify-center rounded-full bg-white shadow-md text-gray-400 hover:text-orange-600 transition-colors">
                  <Heart className="w-3.5 h-3.5" />
                </button>

                {/* Image */}
                <div className="relative w-full aspect-[4/3] bg-gray-100 rounded-t-xl overflow-hidden">
                  <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                  />
                  
                  {/* Quick Add Button - Desktop */}
                  <div className="absolute inset-x-0 bottom-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity hidden md:block bg-gradient-to-t from-black/50 to-transparent">
                      <button 
                        onClick={() => addToCart(product)}
                        className="w-full bg-white text-black py-2 rounded font-bold text-xs hover:bg-black hover:text-white transition-colors uppercase active:scale-95 transform"
                      >
                          Add to Cart
                      </button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-3">
                  <div className="flex items-center gap-1 mb-1">
                      <Star className="w-3 h-3 text-orange-600 fill-orange-600" />
                      <span className="text-xs font-bold text-black">{product.rating}</span>
                      <span className="text-[10px] text-gray-500"> | {product.reviews} reviews</span>
                  </div>
                  <h3 className="font-bold text-sm text-gray-900 mb-1 truncate">{product.name}</h3>
                  {product.dimensions && <p className="text-[10px] text-gray-500 mb-2">{product.dimensions}</p>}
                  
                  <div className="flex items-center gap-2">
                      <span className="font-bold text-base">₹{product.price.toLocaleString()}</span>
                      {product.originalPrice && (
                          <span className="text-xs text-gray-400 line-through">₹{product.originalPrice.toLocaleString()}</span>
                      )}
                  </div>
                  {product.originalPrice && (
                       <span className="text-[10px] font-bold text-green-600 mt-1 block">
                           Save {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                       </span>
                   )}
                   
                   {/* Mobile Add Button */}
                   <button 
                    onClick={() => addToCart(product)}
                    className="md:hidden w-full mt-3 bg-black text-white py-2 rounded font-bold text-xs uppercase active:bg-gray-800"
                   >
                        Add to Cart
                   </button>
                </div>
              </div>
            ))}
            
             {/* View All Card for Mobile Slider */}
             <div className="flex-shrink-0 min-w-[150px] snap-center flex flex-col items-center justify-center bg-gray-50 rounded-xl border-2 border-dashed border-gray-200 md:hidden">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm mb-2">
                    <ArrowRight className="w-5 h-5 text-orange-600" />
                </div>
                <span className="text-xs font-bold text-gray-600">View All</span>
             </div>
          </div>
        ) : (
          <div className="text-center py-20 bg-gray-50 rounded-2xl border-dashed border-2 border-gray-200">
             <p className="text-gray-500 font-medium">No plans match your filters.</p>
             <button onClick={clearFilters} className="mt-4 text-orange-600 font-bold hover:underline">Clear Filters</button>
          </div>
        )}
      </div>
    </section>
  );
};