import React from 'react';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { BLOG_POSTS } from '../constants';

export const BlogSection: React.FC = () => {
  return (
    <section id="blog" className="py-16 bg-white border-t border-gray-100">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex justify-between items-end mb-10">
          <div>
             <h2 className="text-2xl md:text-3xl font-extrabold uppercase tracking-tight text-black">
                Architectural <span className="text-orange-600">Journal</span>
             </h2>
             <p className="text-gray-500 mt-2 text-sm md:text-base">Insights, tips, and trends from our experts.</p>
          </div>
          <button className="hidden md:flex items-center gap-2 text-sm font-bold text-orange-600 hover:text-black transition-colors">
            Read All Articles <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post) => (
            <article key={post.id} className="group cursor-pointer flex flex-col h-full">
              <div className="relative overflow-hidden rounded-xl aspect-[16/10] mb-4">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-orange-600 uppercase tracking-wider">
                  {post.category}
                </div>
              </div>
              
              <div className="flex items-center gap-4 text-xs text-gray-400 mb-3">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {post.date}
                </div>
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  Admin
                </div>
              </div>

              <h3 className="text-xl font-bold mb-3 group-hover:text-orange-600 transition-colors leading-tight">
                {post.title}
              </h3>
              
              <p className="text-gray-500 text-sm mb-4 line-clamp-2 flex-grow">
                {post.excerpt}
              </p>

              <button className="flex items-center gap-1 text-sm font-bold text-black group-hover:text-orange-600 transition-colors mt-auto">
                Read More <ArrowRight className="w-4 h-4" />
              </button>
            </article>
          ))}
        </div>
        
        <button className="md:hidden w-full mt-8 border border-gray-200 py-3 rounded-full font-bold text-sm text-gray-700 hover:bg-gray-50">
           View All Articles
        </button>
      </div>
    </section>
  );
};