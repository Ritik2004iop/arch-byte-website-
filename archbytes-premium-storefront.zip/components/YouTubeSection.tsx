import React from 'react';
import { Play } from 'lucide-react';
import { YOUTUBE_VIDEOS } from '../constants';

export const YouTubeSection: React.FC = () => {
  return (
    <section id="youtube-videos" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-extrabold uppercase tracking-tight">
                Latest from <span className="text-orange-600">YouTube</span>
            </h2>
            <button className="bg-orange-600 text-white px-4 py-2 rounded text-xs font-bold hover:bg-orange-700 transition-colors">
                Subscribe
            </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {YOUTUBE_VIDEOS.map((video) => (
            <div key={video.id} className="group cursor-pointer">
              <div className="relative aspect-video rounded-xl overflow-hidden mb-4 shadow-lg">
                <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 fill-white" />
                    </div>
                </div>
              </div>
              <h3 className="font-bold text-lg leading-tight mb-1 group-hover:text-orange-600 transition-colors">
                  {video.title}
              </h3>
              <p className="text-xs text-gray-500 font-bold">{video.channelName}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};